﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipmentApp
{
    public class Shipment
    {
        public DateTime Data { get; set; }
        public String City { get; set; }
        public String Country { get; set; }
        public String Office { get; set; }
        public String Manager  { get; set; }
        public int Count { get; set; }
        public decimal Sumy { get; set; }
    }
}

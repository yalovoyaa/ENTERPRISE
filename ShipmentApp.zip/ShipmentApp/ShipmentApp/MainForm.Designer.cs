﻿namespace ShipmentApp
{
    partial class MainForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_shipments = new System.Windows.Forms.DataGridView();
            this.chbx_Date = new System.Windows.Forms.CheckBox();
            this.chbx_Org = new System.Windows.Forms.CheckBox();
            this.chbx_City = new System.Windows.Forms.CheckBox();
            this.chbx_Country = new System.Windows.Forms.CheckBox();
            this.chbx_Manager = new System.Windows.Forms.CheckBox();
            this.btn_Select = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btn_Previous = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txbx_kolvoStrok = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_shipments)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv_shipments
            // 
            this.dgv_shipments.AllowUserToAddRows = false;
            this.dgv_shipments.AllowUserToDeleteRows = false;
            this.dgv_shipments.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_shipments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_shipments.Location = new System.Drawing.Point(6, 44);
            this.dgv_shipments.Name = "dgv_shipments";
            this.dgv_shipments.ReadOnly = true;
            this.dgv_shipments.Size = new System.Drawing.Size(633, 272);
            this.dgv_shipments.TabIndex = 0;
            // 
            // chbx_Date
            // 
            this.chbx_Date.AutoSize = true;
            this.chbx_Date.Location = new System.Drawing.Point(47, 21);
            this.chbx_Date.Name = "chbx_Date";
            this.chbx_Date.Size = new System.Drawing.Size(52, 17);
            this.chbx_Date.TabIndex = 1;
            this.chbx_Date.Text = "Дата";
            this.chbx_Date.UseVisualStyleBackColor = true;
            // 
            // chbx_Org
            // 
            this.chbx_Org.AutoSize = true;
            this.chbx_Org.Location = new System.Drawing.Point(109, 21);
            this.chbx_Org.Name = "chbx_Org";
            this.chbx_Org.Size = new System.Drawing.Size(93, 17);
            this.chbx_Org.TabIndex = 2;
            this.chbx_Org.Text = "Организация";
            this.chbx_Org.UseVisualStyleBackColor = true;
            // 
            // chbx_City
            // 
            this.chbx_City.AutoSize = true;
            this.chbx_City.Location = new System.Drawing.Point(208, 21);
            this.chbx_City.Name = "chbx_City";
            this.chbx_City.Size = new System.Drawing.Size(56, 17);
            this.chbx_City.TabIndex = 3;
            this.chbx_City.Text = "Город";
            this.chbx_City.UseVisualStyleBackColor = true;
            // 
            // chbx_Country
            // 
            this.chbx_Country.AutoSize = true;
            this.chbx_Country.Location = new System.Drawing.Point(297, 21);
            this.chbx_Country.Name = "chbx_Country";
            this.chbx_Country.Size = new System.Drawing.Size(62, 17);
            this.chbx_Country.TabIndex = 4;
            this.chbx_Country.Text = "Страна";
            this.chbx_Country.UseVisualStyleBackColor = true;
            // 
            // chbx_Manager
            // 
            this.chbx_Manager.AutoSize = true;
            this.chbx_Manager.Location = new System.Drawing.Point(373, 21);
            this.chbx_Manager.Name = "chbx_Manager";
            this.chbx_Manager.Size = new System.Drawing.Size(79, 17);
            this.chbx_Manager.TabIndex = 5;
            this.chbx_Manager.Text = "Менеджер";
            this.chbx_Manager.UseVisualStyleBackColor = true;
            // 
            // btn_Select
            // 
            this.btn_Select.Location = new System.Drawing.Point(476, 17);
            this.btn_Select.Name = "btn_Select";
            this.btn_Select.Size = new System.Drawing.Size(82, 23);
            this.btn_Select.TabIndex = 6;
            this.btn_Select.Text = "Выбрать";
            this.btn_Select.UseVisualStyleBackColor = true;
            this.btn_Select.Click += new System.EventHandler(this.BtnSelectClick);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(564, 17);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancelClick);
            // 
            // btn_Previous
            // 
            this.btn_Previous.Location = new System.Drawing.Point(12, 349);
            this.btn_Previous.Name = "btn_Previous";
            this.btn_Previous.Size = new System.Drawing.Size(75, 23);
            this.btn_Previous.TabIndex = 8;
            this.btn_Previous.Text = "Назад";
            this.btn_Previous.UseVisualStyleBackColor = true;
            this.btn_Previous.Click += new System.EventHandler(this.btn_Previous_Click);
            // 
            // btn_Next
            // 
            this.btn_Next.Location = new System.Drawing.Point(93, 349);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(75, 23);
            this.btn_Next.TabIndex = 9;
            this.btn_Next.Text = "Далее";
            this.btn_Next.UseVisualStyleBackColor = true;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(191, 354);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Кол-во выбранных записей:";
            // 
            // txbx_kolvoStrok
            // 
            this.txbx_kolvoStrok.Location = new System.Drawing.Point(344, 351);
            this.txbx_kolvoStrok.Name = "txbx_kolvoStrok";
            this.txbx_kolvoStrok.Size = new System.Drawing.Size(96, 20);
            this.txbx_kolvoStrok.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgv_shipments);
            this.groupBox1.Controls.Add(this.chbx_Date);
            this.groupBox1.Controls.Add(this.chbx_Org);
            this.groupBox1.Controls.Add(this.chbx_City);
            this.groupBox1.Controls.Add(this.chbx_Country);
            this.groupBox1.Controls.Add(this.btnCancel);
            this.groupBox1.Controls.Add(this.chbx_Manager);
            this.groupBox1.Controls.Add(this.btn_Select);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(645, 331);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Отгрузка";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 398);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txbx_kolvoStrok);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.btn_Previous);
            this.Name = "MainForm";
            this.Text = "Shipment";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_shipments)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_shipments;
        private System.Windows.Forms.CheckBox chbx_Date;
        private System.Windows.Forms.CheckBox chbx_Org;
        private System.Windows.Forms.CheckBox chbx_City;
        private System.Windows.Forms.CheckBox chbx_Country;
        private System.Windows.Forms.CheckBox chbx_Manager;
        private System.Windows.Forms.Button btn_Select;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btn_Previous;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbx_kolvoStrok;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;
using System.Data.Common;
using System.Globalization;
using System.IO;
using System.Configuration;


namespace ShipmentApp
{
    public partial class MainForm : Form
    {
        public string connectionString = ConfigurationManager.ConnectionStrings["ShipmentConString"].ConnectionString;
              
        int pageSize = 10;
        int pageNumber;

        public MainForm()
        {
            InitializeComponent();
            dgv_shipments.AutoGenerateColumns = true;
            dgv_shipments.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            txbx_kolvoStrok.Text = "10";
        }


        private void GetAllShipments()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    var adapter = new SqlDataAdapter(GetSqlCom(), connection);
                    var ds = new DataSet();
                    adapter.Fill(ds, "Shipment");
                    dgv_shipments.DataSource = null;
                    dgv_shipments.DataSource = ds.Tables[0];
                }
                catch (Exception ex)
                {
                    
                    throw;
                }    
            }        
        }


        private void BtnSelectClick(object sender, EventArgs e)
        {
            GetAllShipments();
        }

        private void BtnCancelClick(object sender, EventArgs e)
        {
            chbx_Date.Checked = false;
            chbx_Org.Checked = false;
            chbx_City.Checked = false;
            chbx_Country.Checked = false;
            chbx_Manager.Checked = false;
            GetAllShipments();
        }

        
        #region
        private void btn_Next_Click(object sender, EventArgs e)
        {
            //if (ds.Tables["Shipment"].Rows.Count < pageSize) return;
            //if (txbx_kolvoStrok.Text.Trim() != null)
            //    try
            //    {
            //        pageSize = Int32.Parse(txbx_kolvoStrok.Text.Trim());
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.ToString());
            //        return;
            //    }
            //pageNumber++;
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //{
            //    adapter = new SqlDataAdapter(GetSqlCom(), connection);
            //    ds.Tables["Shipment"].Rows.Clear();
            //    adapter.Fill(ds, "Shipment");
            //}
        }

        private void btn_Previous_Click(object sender, EventArgs e)
        {
            //if (pageNumber == 0) return;
            //pageNumber--;

            //if (txbx_kolvoStrok.Text.Trim() != null)
            //    try
            //    {
            //        pageSize = Int32.Parse(txbx_kolvoStrok.Text.Trim());
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.ToString());
            //        return;
            //    }

            //using (SqlConnection connection = new SqlConnection(connectionString))
            //{
            //    adapter = new SqlDataAdapter(GetSqlCom(), connection);
            //    ds.Tables["Shipment"].Rows.Clear();
            //    adapter.Fill(ds, "Shipment");
            //}
        }

        public void GetPartShipment()
        {
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //{
            //    adapter = new SqlDataAdapter(GetSqlCom(), connection);
            //    ds = new DataSet();
            //    adapter.Fill(ds, "Shipment");
            //    dgv_shipments.DataSource = ds.Tables[0];
            //}
        }
        #endregion


        private string GetSqlCom()
        {
            var sbSelect = new StringBuilder();
            if (chbx_Date.Checked)
                sbSelect.Append(" ,[Дата]");
            if (chbx_Org.Checked)
                sbSelect.Append(" ,[Организация]");
            if (chbx_City.Checked)
                sbSelect.Append(" ,[Город]");
            if (chbx_Country.Checked)
                sbSelect.Append(" ,[Страна]");
            if (chbx_Manager.Checked)
                sbSelect.Append(" ,[Менеджер]");
            var select = sbSelect.ToString();
            if (select.Length > 3)
                select = select.Substring(2, select.Length - 2);

            StringBuilder sb;
            if (select.Length > 0)
            {
                sb = new StringBuilder("SELECT ");
                sb.Append(select);
                sb.Append(", ");
                sb.Append("SUM([Количество]) as 'Количество', SUM([Сумма]) as 'Сумма' FROM Shipment GROUP BY ");
                sb.Append(select);
            }
            else
            {
                sb = new StringBuilder("SELECT * FROM Shipment");
            }
            return sb.ToString();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Закрыть приложение?", "Shipment", MessageBoxButtons.OKCancel) == DialogResult.OK)
                e.Cancel = false;
            else
                e.Cancel = true;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            GetAllShipments();
        }
    }
}
